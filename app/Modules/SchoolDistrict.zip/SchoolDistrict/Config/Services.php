<?php

namespace Modules\SchoolDistrict\Config;

use CodeIgniter\Config\BaseService;

class Services extends BaseService
{
	//
}
