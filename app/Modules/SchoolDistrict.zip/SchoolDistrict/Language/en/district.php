<?php
return [
    // add
	'district_name' => 'District Name',
    'district_code'=>'District Code',
    'state' => 'State',
    'web_url'=>'Ditrict Website URL',
    'billing_address1'=>'Billing Address 1',
    'billing_address2'=>'Billing Address 2',
    'city'=>'City',
    'state'=>'State',
    'zip_code'=>'Zip Code',
	//edit

	//list-view
]
?>